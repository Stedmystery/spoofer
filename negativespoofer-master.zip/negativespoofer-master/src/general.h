#ifndef GENERAL_H
#define GENERAL_H

#define GNU_EFI_USE_MS_ABI 1
#include <efi.h>
#include <efilib.h>

#endif