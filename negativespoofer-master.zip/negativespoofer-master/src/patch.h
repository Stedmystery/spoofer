#ifndef PATCH_H
#define PATCH_H

#include "general.h"

void PatchType0(SMBIOS_STRUCTURE_TABLE* entry);
void PatchAll(SMBIOS_STRUCTURE_TABLE* entry);

#endif
