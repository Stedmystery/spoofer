#ifndef UTILS_H
#define UTILS_H

int RandomNumber(int l, int h);
void RandomText(char *s, const int len);

#endif