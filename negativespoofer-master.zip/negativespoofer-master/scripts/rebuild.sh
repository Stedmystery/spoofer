./scripts/clean.sh
./scripts/build.sh