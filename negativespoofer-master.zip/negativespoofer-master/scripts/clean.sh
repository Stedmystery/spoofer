# Run in project root
rm -rf ./build