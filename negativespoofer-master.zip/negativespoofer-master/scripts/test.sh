./scripts/rebuild.sh
cd build
../scripts/image.sh
../scripts/vm.sh