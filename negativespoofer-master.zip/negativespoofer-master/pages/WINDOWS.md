# How to compile (Windows)
[Use Linux subsystem for Windows](https://docs.microsoft.com/en-us/windows/wsl/install-win10).